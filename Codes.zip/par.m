function [np, halfy,topout] = par(point_xy,cs)
np = length(point_xy); % number of windows
halfy = cs/2; %half diffrence of two adjacent point
topout = [       ]; % depth of top magnetic layer
%====================== Define some paremeters==========================
end
